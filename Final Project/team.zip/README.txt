README

Course: cs400
Semester: Spring 2019
Project name: Quiz Generator
Team Members:
1. Chenlyu Zhao, lecture 002, czhao96@wisc.edu
2. Congkai Tan, lecture 002, ctan46@wisc.edu
3. Dongyu Ou, lecture 001, dou6@wisc.edu
4. Jiayu Li, lecture 002, li852@wisc.edu
